<div class="row">
    <div class="col-sm-12">
        <div class="card">
        	<div class="card-header">
        		<h5>Tidak ditemukan!</h5>
        		<span>Halaman yang anda minta '<?= $page; ?>' tidak ditemukan. Kembali ke <a href="javascript:window.history.go(-1)">halaman sebelumnya</a>.</span>
        	</div>
            <div class="card-block">
                
            </div>
        </div>
    </div>
</div>